Run file through the game.py file NOT the character.py file.

Enjoy